KONSPEKT: GIT, GITHUB VA TERMINAL

Ushbu papkada Git, GitHub, Terminal, .gitignore, Branch va loyiha talablari bo‘yicha konspekt joylashgan.

Bo‘limlar:
01_Git — Git haqida ma’lumot va asosiy buyruqlar.
02_GitHub — GitHub haqida ma’lumot va asosiy buyruqlar.
03_Terminal — Terminal haqida ma’lumot va asosiy buyruqlar.
04_Loyiha — .gitignore, Branch, loyiha talablari va yakuniy xulosa.
